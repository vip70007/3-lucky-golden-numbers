# Lucky Numbers Scratch
Upload this to GitHub Pages to host.